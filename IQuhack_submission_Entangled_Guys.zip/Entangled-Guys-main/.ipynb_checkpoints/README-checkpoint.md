# Holographic-QEC
IQuHack-2022 Qutech-QEC.
